// BSN KEPCO - Background Service Worker
// 흐름: 테이블 추출 → body 교체 → CSS로 상단/하단 잘라내기 → 캡처 → Canvas 여백 크롭

// ★ 주소 조회 모드 탭 추적 (리다이렉트 시에도 유지)
const addrFetchTabs = new Set();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log('[BSN-BG]', msg.type);

  // ★ 탭이 주소 조회 모드인지 등록/확인
  if (msg.type === 'KEPCO_REGISTER_ADDR_TAB') {
    const tabId = sender.tab ? sender.tab.id : null;
    if (tabId) { addrFetchTabs.add(tabId); console.log('[BSN-BG] Registered addr-fetch tab:', tabId); }
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === 'KEPCO_CHECK_ADDR_TAB') {
    const tabId = sender.tab ? sender.tab.id : null;
    const isAddrMode = tabId ? addrFetchTabs.has(tabId) : false;
    console.log('[BSN-BG] Check addr-fetch tab:', tabId, '→', isAddrMode);
    sendResponse({ isAddrMode: isAddrMode });
    return true; // keep channel open for async
  }

  if (msg.type === 'KEPCO_CAPTURE_AND_SEND') {
    const tabId = sender.tab ? sender.tab.id : null;
    // ★ 주소 조회 탭이면 캡처 차단
    if (tabId && addrFetchTabs.has(tabId)) {
      console.log('[BSN-BG] ⛔ Blocked capture on addr-fetch tab:', tabId);
      sendResponse({ ok: false, reason: 'addr_mode' });
      return;
    }
    const windowId = sender.tab ? sender.tab.windowId : null;
    if (tabId && windowId) {
      captureAndStore(tabId, windowId, msg.info, msg.docHeight, msg.viewHeight);
    }
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === 'KEPCO_ADDR_EXTRACT') {
    // 새 형식 KEPCO 페이지에서 추출한 주소를 BSN 앱에 전달
    const kepcoTabId = sender.tab ? sender.tab.id : null;
    (async () => {
      try {
        const allTabs = await chrome.tabs.query({});
        let bsnTab = allTabs.find(t => t.url && (t.url.includes('localhost') || t.url.includes('127.0.0.1') || t.url.includes('ppjd1.github.io')) && t.title && t.title.toUpperCase().includes('BSN'));
        if (!bsnTab) bsnTab = allTabs.find(t => t.title && t.title.toUpperCase().includes('BSN'));
        if (bsnTab) {
          const payload = JSON.stringify(msg.info);
          await chrome.scripting.executeScript({
            target: { tabId: bsnTab.id },
            func: (json) => { localStorage.setItem('bsn_kepco_addr', json); },
            args: [payload]
          });
          console.log('[BSN-BG] ✅ Addr delivered to BSN tab=' + bsnTab.id);
          // ★ BSN 탭으로 포커스 전환
          try {
            await chrome.tabs.update(bsnTab.id, { active: true });
            await chrome.windows.update(bsnTab.windowId, { focused: true });
          } catch(e2) { console.warn('[BSN-BG] Focus BSN failed:', e2.message); }
        }
      } catch(e) { console.error('[BSN-BG] Addr delivery failed:', e.message); }
      // ★ 주소 조회 탭 먼저 닫고 → BSN 포커스 (닫기가 뒤면 브라우저가 다른 탭으로 점프)
      if (kepcoTabId) { addrFetchTabs.delete(kepcoTabId); try { await chrome.tabs.remove(kepcoTabId); } catch(e){} }
      // ★ 탭 닫은 후 BSN 포커스 재시도
      try {
        const allTabs2 = await chrome.tabs.query({});
        let bsnTab2 = allTabs2.find(t => t.url && (t.url.includes('localhost') || t.url.includes('127.0.0.1') || t.url.includes('ppjd1.github.io')) && t.title && t.title.toUpperCase().includes('BSN'));
        if (!bsnTab2) bsnTab2 = allTabs2.find(t => t.title && t.title.toUpperCase().includes('BSN'));
        if (bsnTab2) {
          await chrome.tabs.update(bsnTab2.id, { active: true });
          await chrome.windows.update(bsnTab2.windowId, { focused: true });
        }
      } catch(e3) {}
    })();
    sendResponse({ ok: true });
    return;
  }

  // ★ 캡처 시작 시 BSN 창을 왼쪽 절반으로 배치
  if (msg.type === 'KEPCO_ARRANGE_SPLIT') {
    const tabId = sender.tab ? sender.tab.id : null;
    const winId = sender.tab ? sender.tab.windowId : null;
    (async () => {
      try {
        const screenW = msg.screenW || 1920;
        const screenH = msg.screenH || 1080;
        const halfW = Math.floor(screenW / 2);
        // BSN 창을 왼쪽 절반으로
        if (winId) {
          await chrome.windows.update(winId, { left: 0, top: 0, width: halfW, height: screenH });
        }
        sendResponse({ ok: true, halfW: halfW, screenH: screenH });
      } catch(e) {
        sendResponse({ ok: false, error: e.message });
      }
    })();
    return true; // async
  }

  // ★ 캡처 종료 시 BSN 창 원래대로 복귀
  if (msg.type === 'KEPCO_RESTORE_WINDOW') {
    const winId = sender.tab ? sender.tab.windowId : null;
    if (winId && msg.origW && msg.origH) {
      chrome.windows.update(winId, {
        left: msg.origLeft || 0, top: msg.origTop || 0,
        width: msg.origW, height: msg.origH
      }).catch(()=>{});
    }
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === 'KEPCO_CLOSE_THIS_TAB') {
    const tabId = sender.tab ? sender.tab.id : null;
    if (tabId) {
      addrFetchTabs.delete(tabId);
      try { chrome.tabs.remove(tabId); } catch(e) {}
      console.log('[BSN-BG] Closed tab on request:', tabId);
    }
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === 'BSN_REGISTER_APP') {
    sendResponse({ ok: true });
    return;
  }

  return false;

});

// ★ 탭 닫힘 시 추적 정리
chrome.tabs.onRemoved.addListener((tabId) => {
  addrFetchTabs.delete(tabId);
});

// ★ KEPCO URL에 bsn_addr=1이 있는 탭 → 최초 네비게이션에서 addr 모드 등록
// KEPCO 서버가 리다이렉트하면서 파라미터를 버리므로, 최초 URL에서 캐치해야 함
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  if (!details.url.includes('cyber.kepco.co.kr')) return;
  if (!details.url.includes('bsn_addr=1')) return;
  const tabId = details.tabId;
  if (!addrFetchTabs.has(tabId)) {
    addrFetchTabs.add(tabId);
    console.log('[BSN-BG] ★ Pre-registered addr-fetch tab (onBeforeNavigate):', tabId);
  }
});

// ★ KEPCO 탭에서 새 탭이 열리면 (상세보기/인증 클릭 등) → addr 모드 전파 + 오른쪽 고정 + 원래 탭 닫기
chrome.webNavigation.onCreatedNavigationTarget.addListener((details) => {
  const sourceTabId = details.sourceTabId;
  const newTabId = details.tabId;

  // ★ KEPCO 관련 새 탭이면 오른쪽 절반으로 위치 이동
  (async () => {
    try {
      const newTab = await chrome.tabs.get(newTabId);
      if (newTab && newTab.windowId) {
        const allWindows = await chrome.windows.getAll();
        // BSN 창(가장 왼쪽에 있는 창)의 크기로 화면 절반 계산
        let screenW = 1920, screenH = 1080;
        for (const w of allWindows) {
          if (w.left <= 10 && w.width > 400) {
            screenW = (w.width) * 2; // BSN이 왼쪽 절반이면 전체폭 = 2배
            screenH = w.height;
            break;
          }
        }
        const halfW = Math.floor(screenW / 2);
        await chrome.windows.update(newTab.windowId, { left: halfW, top: 0, width: halfW, height: screenH });
        console.log('[BSN-BG] ★ Moved new KEPCO tab to right half: tabId=' + newTabId + ' winId=' + newTab.windowId);
      }
    } catch(e) { console.warn('[BSN-BG] Move new tab failed:', e.message); }
  })();

  if (addrFetchTabs.has(sourceTabId)) {
    addrFetchTabs.add(newTabId);
    console.log('[BSN-BG] ★ Propagated addr mode: source=' + sourceTabId + ' → new=' + newTabId);
    // 원래 요약 페이지 탭 닫기 (인증 전 중간 페이지)
    setTimeout(() => {
      try { chrome.tabs.remove(sourceTabId); } catch(e) {}
      addrFetchTabs.delete(sourceTabId);
      console.log('[BSN-BG] Closed source tab:', sourceTabId);
    }, 500);
  }
});

async function captureAndStore(kepcoTabId, windowId, info, docHeight, viewHeight) {
  const images = [];
  let origWindow = null;
  const dbg = []; // 누적 디버그
  const saveDbg = async (s) => { dbg.push(s); try { await chrome.storage.local.set({ bsnDebug: { steps: dbg, ts: Date.now() } }); } catch(e){} };

  try {
    origWindow = await chrome.windows.get(windowId);
    // ★ KEPCO 창을 오른쪽 절반에 고정 배치
    const screenW = info._screenW || 1920;
    const screenH = info._screenH || 1080;
    const halfW = Math.floor(screenW / 2);
    await chrome.windows.update(windowId, { focused: true, left: halfW, top: 0, width: halfW, height: screenH });
    await chrome.tabs.update(kepcoTabId, { active: true });
    await sleep(500);
    await saveDbg('0_start');

    // 1) 청구서 테이블 추출 → body 교체 → 상단/하단 CSS 크롭 → 좌표 반환
    const extracted = await chrome.scripting.executeScript({
      target: { tabId: kepcoTabId },
      func: () => {
        const tables = document.querySelectorAll('table');
        let best = null, bestScore = 0;

        tables.forEach(t => {
          const txt = t.innerText || '';
          const rect = t.getBoundingClientRect();
          if (rect.width < 300 || rect.height < 200) return;
          let score = 0;
          if (txt.includes('청구금액')) score += 5;
          if (txt.includes('고객번호') || txt.includes('고 객 번 호')) score += 4;
          if (txt.includes('사용량')) score += 3;
          if (txt.includes('전기요금')) score += 3;
          if (txt.includes('납기일') || txt.includes('납부기한')) score += 2;
          if (txt.includes('이메일 청구서')) score += 2;
          if (txt.includes('사용기간')) score += 2;
          if (rect.width > 400 && rect.width < 900) score += 2;
          if (rect.height > 500) score += 1;
          if (rect.height > window.innerHeight * 4) score -= 3;
          if (score > bestScore) { bestScore = score; best = t; }
        });

        if (!best || bestScore < 5) {
          return { ok: false, height: document.body.scrollHeight, width: document.body.scrollWidth };
        }

        const origWidth = Math.ceil(best.getBoundingClientRect().width);
        const clone = best.cloneNode(true);

        // body 교체
        document.body.innerHTML = '';
        document.body.appendChild(clone);
        document.body.style.cssText = 'margin:0;padding:0;background:#fff;overflow:hidden;';
        document.documentElement.style.cssText = 'margin:0;padding:0;overflow:hidden;';
        window.scrollTo(0, 0);

        // ── 파란 박스 상단 좌표 측정 ──
        let blueTop = 0;
        const allEls = clone.querySelectorAll('td, th, div, span, tr');
        // 1차: "전기요금 이메일 청구서" 텍스트
        for (let i = 0; i < allEls.length; i++) {
          const el = allEls[i];
          const txt = (el.innerText || '').replace(/\s+/g, '');
          if ((txt.includes('전기요금') && txt.includes('이메일') && txt.includes('청구서') && txt.length < 40) ||
              (txt === '전기요금이메일청구서')) {
            const rect = el.getBoundingClientRect();
            if (rect.height > 3 && rect.height < 100 && rect.width > 50) {
              blueTop = Math.floor(rect.top);
              console.log('[CROP] Blue box: top=' + blueTop + ' h=' + rect.height + ' text="' + txt.substring(0, 25) + '"');
              break;
            }
          }
        }
        // 2차: "고객님의" 텍스트 (파란 박스 바로 위 or 포함)
        if (!blueTop) {
          for (let i = 0; i < allEls.length; i++) {
            const el = allEls[i];
            const txt = (el.innerText || '').trim();
            if (txt.includes('고객님의') && txt.includes('월') && txt.length < 50) {
              const rect = el.getBoundingClientRect();
              if (rect.height > 3 && rect.width > 50) {
                blueTop = Math.floor(rect.top);
                console.log('[CROP] 고객님의: top=' + blueTop);
                break;
              }
            }
          }
        }
        // 3차: "청구내역" (고압 청구서는 파란박스 없이 바로 시작)
        if (!blueTop) {
          for (let i = 0; i < allEls.length; i++) {
            const el = allEls[i];
            const txt = (el.innerText || '').replace(/\s+/g, '');
            if ((txt === '청구내역' || txt === '청구금액') && txt.length < 10) {
              const rect = el.getBoundingClientRect();
              if (rect.height > 3 && rect.width > 30) {
                blueTop = Math.max(0, Math.floor(rect.top) - 3);
                console.log('[CROP] 청구내역: top=' + blueTop);
                break;
              }
            }
          }
        }

        // ── 하단 좌표 측정: 계좌번호 마지막 줄(IM뱅크 줄) 하단에서 자르기 ──
        let cutBottom = 0;
        const bankNames = ['은행','농협','국민','신한','우리','하나','기업','수협','대구','부산','경남','광주','전북','제주','SC','씨티','카카오','토스','케이','IM뱅크','iM뱅크','IM','뱅크'];
        const allEls2 = clone.querySelectorAll('td, th, div, span, tr, a, input, button, img');
        // 모든 은행/계좌 관련 요소를 찾아서 가장 아래쪽 좌표 사용
        for (let i = 0; i < allEls2.length; i++) {
          const el = allEls2[i];
          const txt = (el.innerText || el.value || el.alt || '').replace(/\s+/g, '');
          const txtRaw = (el.innerText || el.value || el.alt || '').trim();
          let isAccount = false;
          // "계좌번호", "가상계좌", "납부+계좌/은행"
          if (txt.includes('계좌번호') || txt.includes('가상계좌') ||
              (txt.includes('납부') && (txt.includes('은행') || txt.includes('계좌')))) {
            isAccount = true;
          }
          // 은행명이 포함된 셀
          if (!isAccount) {
            for (let b = 0; b < bankNames.length; b++) {
              if (txt.includes(bankNames[b])) {
                // 은행명 + 숫자가 있으면 계좌 줄
                if (/[0-9]{3,}/.test(txt)) { isAccount = true; break; }
              }
            }
          }
          if (isAccount) {
            const rect = el.getBoundingClientRect();
            if (rect.height > 0 && rect.width > 0) {
              const bot = Math.ceil(rect.bottom) + 15;
              if (bot > cutBottom) {
                cutBottom = bot;
                console.log('[CROP] 계좌: bot=' + bot + ' txt="' + txtRaw.substring(0, 30) + '"');
              }
            }
          }
        }
        // 3차: "신용카드납부" (계좌번호 못 찾으면)
        if (!cutBottom) {
          for (let i = allEls2.length - 1; i >= 0; i--) {
            const el = allEls2[i];
            const txt = (el.innerText || el.value || el.alt || '').replace(/\s+/g, '');
            if (txt.includes('신용카드납부') || txt.includes('신용카드결제') ||
                txt.includes('현재') && txt.includes('미납') ||
                txt.includes('인쇄') || txt === '프린트') {
              const rect = el.getBoundingClientRect();
              if (rect.height > 0 && rect.width > 0) {
                const bot = Math.ceil(rect.bottom) + 5;
                if (bot > cutBottom) {
                  cutBottom = bot;
                  console.log('[CROP] Fallback bottom: bot=' + bot + ' txt="' + txt.substring(0, 20) + '"');
                }
              }
            }
          }
        }
        const fullHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
        if (!cutBottom || cutBottom < 100) cutBottom = fullHeight;

        console.log('[CROP] FINAL: blueTop=' + blueTop + ' cutBottom=' + cutBottom + ' fullH=' + fullHeight);

        // ── CSS로 상단/하단 잘라내기 ──
        const cropH = cutBottom - blueTop;
        const wrapper = document.createElement('div');
        wrapper.style.cssText = 'overflow:hidden;height:' + cropH + 'px;position:relative;';
        clone.style.marginTop = '-' + blueTop + 'px';
        document.body.innerHTML = '';
        wrapper.appendChild(clone);
        document.body.appendChild(wrapper);
        document.body.style.cssText = 'margin:0;padding:0;background:#fff;overflow:hidden;';
        document.documentElement.style.cssText = 'margin:0;padding:0;overflow:hidden;';
        window.scrollTo(0, 0);

        const contentWidth = Math.ceil(clone.getBoundingClientRect().width) || origWidth;

        return {
          ok: true,
          width: contentWidth,
          height: cropH,
          cropTop: 0,
          cropBottom: cropH
        };
      }
    });

    const ext = extracted[0].result;
    console.log('[BSN-BG] Extract:', JSON.stringify(ext));
    await saveDbg('1_ext:ok=' + ext.ok + ',w=' + ext.width + ',h=' + ext.height + ',cropB=' + ext.cropBottom);
    await sleep(300);

    const cropHeight = ext.cropBottom || ext.height;
    console.log('[BSN-BG] Crop height=' + cropHeight);

    // 2) 창 크기 최대로 — 화질을 위해 줌을 최소화하려면 창이 커야 함
    const targetWidth = ext.ok ? Math.min(ext.width + 20, 800) : 580;
    // ★ 오른쪽 절반에 고정 배치 (캡처 중 왼쪽으로 안 넘어가게)
    const capLeft = halfW;
    try {
      await chrome.windows.update(windowId, { width: targetWidth, height: 1400, top: 0, left: capLeft });
    } catch(e) {
      try { await chrome.windows.update(windowId, { width: targetWidth, height: 1080, left: capLeft }); } catch(e2) {}
    }
    await sleep(500);

    // 3) 뷰포트 측정
    const measured = await chrome.scripting.executeScript({
      target: { tabId: kepcoTabId },
      func: () => {
        window.scrollTo(0, 0);
        return { viewH: window.innerHeight, docH: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) };
      }
    });
    const m = measured[0].result;

    // 줌 계산 — 화질 우선: 최소 0.9, 가능하면 1.0 (안 맞으면 2장 스티칭)
    let zoomLevel = (m.viewH / cropHeight);
    zoomLevel = Math.max(0.9, Math.min(1.0, zoomLevel));
    console.log('[BSN-BG] Zoom:', zoomLevel, 'viewH:', m.viewH, 'cropH:', cropHeight);

    const fitsInOne = (cropHeight * zoomLevel) <= (m.viewH + 20);
    await saveDbg('2_zoom=' + zoomLevel.toFixed(2) + ',viewH=' + m.viewH + ',cropH=' + cropHeight + ',fit=' + fitsInOne);

    if (fitsInOne) {
      // ── 1장 캡처 ──
      await chrome.tabs.setZoom(kepcoTabId, zoomLevel);
      await sleep(600);
      await chrome.scripting.executeScript({
        target: { tabId: kepcoTabId },
        func: () => window.scrollTo(0, 0)
      });
      await sleep(300);

      const rawImg = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });
      await saveDbg('3_cap=' + (rawImg||'').length);

      // Canvas: 흰 여백만 자동 크롭
      const cropped = await chrome.scripting.executeScript({
        target: { tabId: kepcoTabId },
        func: (imgData) => {
          return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
              const canvas = document.createElement('canvas');
              const ctx = canvas.getContext('2d');
              canvas.width = img.width;
              canvas.height = img.height;
              ctx.drawImage(img, 0, 0);

              const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
              const data = imageData.data;
              const w = canvas.width, h = canvas.height;
              let top = h, left = w, right = 0, bottom = 0;
              for (let y = 0; y < h; y++) {
                for (let x = 0; x < w; x++) {
                  const idx = (y * w + x) * 4;
                  if (data[idx] < 248 || data[idx+1] < 248 || data[idx+2] < 248) {
                    if (y < top) top = y;
                    if (y > bottom) bottom = y;
                    if (x < left) left = x;
                    if (x > right) right = x;
                  }
                }
              }
              if (top >= bottom || left >= right) { resolve(imgData); return; }
              const pad = 3;
              top = Math.max(0, top - pad);
              left = Math.max(0, left - pad);
              right = Math.min(w - 1, right + pad);
              bottom = Math.min(h - 1, bottom + pad);

              const cw = right - left + 1, ch = bottom - top + 1;
              const cropCanvas = document.createElement('canvas');
              cropCanvas.width = cw;
              cropCanvas.height = ch;
              cropCanvas.getContext('2d').drawImage(img, left, top, cw, ch, 0, 0, cw, ch);
              resolve(cropCanvas.toDataURL('image/jpeg', 0.92));
            };
            img.onerror = () => resolve(imgData);
            img.src = imgData;
          });
        },
        args: [rawImg]
      });

      var cropResult = cropped[0].result || '';
      // ★ 캡처 검증: 이미지 크기 + 해상도 체크
      var capValid = await chrome.scripting.executeScript({
        target: { tabId: kepcoTabId },
        func: (imgData) => {
          return new Promise((resolve) => {
            var img = new Image();
            img.onload = () => resolve({ w: img.naturalWidth, h: img.naturalHeight, size: imgData.length, ok: img.naturalWidth > 200 && img.naturalHeight > 200 && imgData.length > 5000 });
            img.onerror = () => resolve({ w: 0, h: 0, size: imgData.length, ok: false });
            img.src = imgData;
          });
        },
        args: [cropResult]
      });
      var cv = capValid[0].result;
      console.log('[BSN-BG] Capture validate:', cv.w + 'x' + cv.h, 'size=' + Math.round(cv.size/1024) + 'KB', cv.ok ? 'OK' : 'BAD');
      await saveDbg('4_crop=' + cv.size + ',dim=' + cv.w + 'x' + cv.h + ',ok=' + cv.ok);

      if (!cv.ok && cv.size < 5000) {
        // 너무 작으면 재시도 1회
        console.log('[BSN-BG] ⚠ 캡처 품질 불량 — 재시도...');
        await sleep(1000);
        await chrome.windows.update(windowId, { focused: true });
        await chrome.tabs.update(kepcoTabId, { active: true });
        await sleep(500);
        await chrome.scripting.executeScript({ target: { tabId: kepcoTabId }, func: () => window.scrollTo(0, 0) });
        await sleep(300);
        var retryRaw = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });
        var retryCrop = await chrome.scripting.executeScript({
          target: { tabId: kepcoTabId },
          func: (imgData) => {
            return new Promise((resolve) => {
              var img = new Image();
              img.onload = () => {
                var c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
                var ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0);
                var id = ctx.getImageData(0,0,c.width,c.height), d = id.data, w = c.width, h = c.height;
                var t=h,l=w,r=0,b=0;
                for(var y=0;y<h;y++) for(var x=0;x<w;x++){ var i=(y*w+x)*4; if(d[i]<248||d[i+1]<248||d[i+2]<248){ if(y<t)t=y;if(y>b)b=y;if(x<l)l=x;if(x>r)r=x; }}
                if(t>=b){resolve(imgData);return;}
                t=Math.max(0,t-3);l=Math.max(0,l-3);r=Math.min(w-1,r+3);b=Math.min(h-1,b+3);
                var cc=document.createElement('canvas');cc.width=r-l+1;cc.height=b-t+1;
                cc.getContext('2d').drawImage(img,l,t,cc.width,cc.height,0,0,cc.width,cc.height);
                resolve(cc.toDataURL('image/jpeg',0.92));
              };
              img.onerror = () => resolve(imgData);
              img.src = imgData;
            });
          },
          args: [retryRaw]
        });
        cropResult = retryCrop[0].result || cropResult;
        console.log('[BSN-BG] Retry result size=' + Math.round(cropResult.length/1024) + 'KB');
      }

      images.push({ zone: 'full', dataUrl: cropResult, _w: cv.w, _h: cv.h });
      await chrome.tabs.setZoom(kepcoTabId, 1.0);

    } else {
      // ── 2장 캡처 + 스티칭 ──
      const stitchZoom = Math.max(0.85, Math.min(1.0, (m.viewH / cropHeight) * 1.8));
      await chrome.tabs.setZoom(kepcoTabId, stitchZoom);
      await sleep(600);

      // 상단 캡처
      await chrome.scripting.executeScript({
        target: { tabId: kepcoTabId },
        func: () => window.scrollTo(0, 0)
      });
      await sleep(400);
      const topImg = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });

      // 하단 캡처 (맨 아래로)
      await chrome.scripting.executeScript({
        target: { tabId: kepcoTabId },
        func: () => window.scrollTo(0, document.body.scrollHeight)
      });
      await sleep(400);
      const bottomImg = await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });

      // 스티칭 — 실제 겹침량 계산
      const mAfterZoom = await chrome.scripting.executeScript({
        target: { tabId: kepcoTabId },
        func: () => ({ viewH: window.innerHeight, docH: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight) })
      });
      const mz = mAfterZoom[0].result;
      // 실제 겹침 = viewH*2 - docH (두번 캡처시 겹치는 CSS 높이)
      const realOverlapCSS = Math.max(0, mz.viewH * 2 - mz.docH);

      const stitched = await chrome.scripting.executeScript({
        target: { tabId: kepcoTabId },
        func: (topData, bottomData, overlapRatio) => {
          return new Promise((resolve) => {
            const imgT = new Image(), imgB = new Image();
            let loaded = 0;
            const done = () => {
              if (++loaded < 2) return;
              // overlapRatio = CSS겹침/CSS뷰포트높이 → 캡처이미지에 적용
              const overlap = Math.floor(imgT.height * overlapRatio);
              const totalH = imgT.height + imgB.height - overlap;
              const canvas = document.createElement('canvas');
              canvas.width = Math.max(imgT.width, imgB.width);
              canvas.height = totalH;
              const ctx = canvas.getContext('2d');
              ctx.fillStyle = '#fff';
              ctx.fillRect(0, 0, canvas.width, canvas.height);
              ctx.drawImage(imgT, 0, 0);
              ctx.drawImage(imgB, 0, imgT.height - overlap);

              // 흰 여백 자동 크롭
              const id = ctx.getImageData(0, 0, canvas.width, canvas.height);
              const d = id.data, w = canvas.width, h = canvas.height;
              let t = h, l = w, r = 0, b = 0;
              for (let y = 0; y < h; y += 2) {
                for (let x = 0; x < w; x++) {
                  const idx = (y * w + x) * 4;
                  if (d[idx] < 248 || d[idx+1] < 248 || d[idx+2] < 248) {
                    if (y < t) t = y; if (y > b) b = y;
                    if (x < l) l = x; if (x > r) r = x;
                  }
                }
              }
              if (t >= b) { resolve(canvas.toDataURL('image/jpeg', 0.92)); return; }
              t = Math.max(0, t - 3); l = Math.max(0, l - 3);
              r = Math.min(w - 1, r + 3); b = Math.min(h - 1, b + 3);
              const cc = document.createElement('canvas');
              cc.width = r - l + 1; cc.height = b - t + 1;
              cc.getContext('2d').drawImage(canvas, l, t, cc.width, cc.height, 0, 0, cc.width, cc.height);
              resolve(cc.toDataURL('image/jpeg', 0.92));
            };
            imgT.onload = done; imgB.onload = done;
            imgT.src = topData; imgB.src = bottomData;
          });
        },
        args: [topImg, bottomImg, mz.viewH > 0 ? (realOverlapCSS / mz.viewH) : 0.1]
      });

      var stitchResult = stitched[0].result || '';
      images.push({ zone: 'full', dataUrl: stitchResult, _size: stitchResult.length });
      await chrome.tabs.setZoom(kepcoTabId, 1.0);
    }

    // 창 크기 원복 (오른쪽 고정 유지)
    if (origWindow) {
      await chrome.windows.update(windowId, { width: origWindow.width, height: origWindow.height, left: halfW });
    }

  } catch (err) {
    console.error('[BSN-BG] Capture error:', err.message);
    await saveDbg('ERR:' + err.message);
    if (origWindow) {
      try { await chrome.windows.update(windowId, { width: origWindow.width, height: origWindow.height, left: halfW }); } catch(e) {}
    }
  }

  try { await chrome.tabs.remove(kepcoTabId); } catch(e) {}
  if (!images.length) {
    console.error('[BSN-BG] No images!');
    await saveDbg('NO_IMAGES');
    return;
  }

  var totalSize = images.reduce((s, img) => s + (img.dataUrl || '').length, 0);
  console.log('[BSN-BG] Delivering images: count=' + images.length + ' totalSize=' + Math.round(totalSize/1024) + 'KB');

  // ── 1) storage.local에 항상 저장 (app-bridge.js 폴링용 백업) ──
  try {
    await chrome.storage.local.set({
      bsnCapturedImages: { custNo: info.custNo || '', period: info.period || '', images, timestamp: Date.now() }
    });
    console.log('[BSN-BG] Storage saved OK');
  } catch(e) {
    console.warn('[BSN-BG] Storage save failed:', e.message);
  }

  // ── 2) BSN 탭 찾기 (넓은 범위 검색) ──
  let bsnTab = null;
  try {
    const allTabs = await chrome.tabs.query({});
    console.log('[BSN-BG] Total tabs:', allTabs.length);
    // 1차: title에 BSN 포함 + localhost/127.0.0.1/file:///github.io
    bsnTab = allTabs.find(t => t.url && (t.url.includes('localhost') || t.url.includes('127.0.0.1') || t.url.startsWith('file://') || t.url.includes('ppjd1.github.io')) && t.title && t.title.toUpperCase().includes('BSN'));
    // 2차: title만으로 검색 (URL 조건 완화)
    if (!bsnTab) {
      bsnTab = allTabs.find(t => t.title && t.title.toUpperCase().includes('BSN'));
    }
    // 3차: URL에 index.html 포함
    if (!bsnTab) {
      bsnTab = allTabs.find(t => t.url && (t.url.includes('localhost') || t.url.includes('127.0.0.1') || t.url.includes('ppjd1.github.io')) && t.url.includes('index.html'));
    }
    if (bsnTab) {
      console.log('[BSN-BG] Found BSN tab: id=' + bsnTab.id + ' url=' + (bsnTab.url||'').substring(0,60) + ' title=' + bsnTab.title);
    } else {
      console.warn('[BSN-BG] BSN tab NOT found among', allTabs.map(t => (t.title||'').substring(0,20) + '|' + (t.url||'').substring(0,40)).join(' ; '));
    }
  } catch(e) {
    console.error('[BSN-BG] Tab query error:', e.message);
  }

  // ── 3) localStorage 경유 전달 (ISOLATED world → 페이지와 공유) ──
  if (bsnTab) {
    try {
      const payload = JSON.stringify({ custNo: info.custNo || '', period: info.period || '', images });
      await chrome.scripting.executeScript({
        target: { tabId: bsnTab.id },
        func: (json) => {
          localStorage.setItem('bsn_kepco_captured', json);
        },
        args: [payload]
      });
      console.log('[BSN-BG] ✅ localStorage delivery OK, tab=' + bsnTab.id);
      await saveDbg('5_delivered:tab=' + bsnTab.id + ',sz=' + payload.length);
      // ★ 캡처 전달 후 BSN 탭으로 포커스 복귀 → 미리보기 확인 가능
      try {
        await chrome.tabs.update(bsnTab.id, { active: true });
        await chrome.windows.update(bsnTab.windowId, { focused: true });
        console.log('[BSN-BG] Focused BSN tab after capture delivery');
      } catch(e2) {}
    } catch (e) {
      console.error('[BSN-BG] localStorage delivery failed:', e.message);
      await saveDbg('5_ERR:' + e.message);
    }
  } else {
    await saveDbg('5_NO_BSN_TAB');
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
