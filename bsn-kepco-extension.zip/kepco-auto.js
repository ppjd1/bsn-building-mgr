// BSN KEPCO 자동 네비게이션 + 캡처 트리거 - cyber.kepco.co.kr 전용
// ★ document_start에서 실행 — URL 등록은 즉시, DOM 작업은 DOMContentLoaded 이후
(function() {
  'use strict';
  const url = location.href;
  console.log('[BSN-KEPCO] Script injected (document_start):', url);

  // ═══════════════════════════════════════════════════════
  // 1단계: 즉시 실행 (DOM 불필요) — addr 탭 등록
  // ═══════════════════════════════════════════════════════
  const isFetchAddrModeUrl = url.includes('bsn_addr=1');
  if (isFetchAddrModeUrl) {
    chrome.runtime.sendMessage({ type: 'KEPCO_REGISTER_ADDR_TAB' });
    console.log('[BSN-KEPCO] ★ Registered addr-fetch tab (immediate)');
  }

  // ═══════════════════════════════════════════════════════
  // 2단계: DOM 준비 후 실행
  // ═══════════════════════════════════════════════════════
  function onDomReady() {
    console.log('[BSN-KEPCO] DOM ready, starting flow check');

    // background에 addr-fetch 탭인지 확인 후 흐름 실행
    chrome.runtime.sendMessage({ type: 'KEPCO_CHECK_ADDR_TAB' }, function(response) {
      const isAddrMode = isFetchAddrModeUrl || (response && response.isAddrMode);
      console.log('[BSN-KEPCO] isAddrMode:', isAddrMode);
      runFlow(isAddrMode);
    });
  }

  // document_start에서는 DOM이 아직 없으므로 readyState 체크
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onDomReady);
  } else {
    // 이미 DOM 준비됨 (드물지만 안전장치)
    onDomReady();
  }

  // ── 주소 추출 공통 함수 ──
  function extractAddrInfo() {
    const bodyText = document.body.innerText || '';
    const info = {};
    try { info.urlCustid = new URLSearchParams(location.search).get('custid') || ''; } catch(e){}
    const cm = bodyText.match(/고\s*객\s*번\s*호\s*[:：]?\s*([\d\-]+)/);
    if (cm) info.custNo = cm[1].replace(/-/g, '');
    const cityRe = '(?:서울|부산|대구|인천|광주|대전|울산|세종|경기|강원|충북|충남|전북|전남|경북|경남|제주)';
    // 1차: "주소" 라벨 뒤에 도시명
    const addrMatch = bodyText.match(new RegExp('주\\s*소\\s*[:：]?\\s*(' + cityRe + '[^\\n]{5,80})'));
    if (addrMatch) {
      info.addr = addrMatch[1].trim().replace(/\s+/g,' ');
    } else {
      // 2차: "주소" 라벨 없이 도시명+구/군+도로명/동명 패턴 (NEW5 상세 청구서용)
      // "서울특별시 영등포구 양산로17길 2 (당산동3가 522-3 )" 같은 형태
      const addrMatch2 = bodyText.match(new RegExp('(' + cityRe + '(?:특별시|광역시|특별자치시|특별자치도|도)?\\s+[가-힣]+(?:구|시|군)\\s+[가-힣0-9*]+(?:로|길|동)\\s*[^\\n]{2,60})'));
      if (addrMatch2) info.addr = addrMatch2[1].trim().replace(/\s+/g,' ').replace(/\s*(님|고객님).*$/, '');
    }
    const nm = bodyText.match(/고\s*객\s*(?:명|성명)\s*[:：]?\s*([가-힣A-Za-z＊*\s()]{1,30})/);
    if (nm) info.custName = nm[1].trim();
    // 폴백: "OOO 고객님의" 패턴 (NEW5 상세 청구서)
    if (!info.custName) {
      const nm2 = bodyText.match(/([가-힣A-Za-z()]+(?:주식회사|유한회사|㈜)?[가-힣A-Za-z＊*\s()]{1,30}?)\s*고객님/);
      if (nm2) info.custName = nm2[1].trim();
    }
    const pm = bodyText.match(/(\d{4})\s*년\s*(\d{1,2})\s*월/);
    if (pm) info.period = pm[1] + '-' + String(parseInt(pm[2])).padStart(2, '0');
    return info;
  }

  // ★ 주소에 마스킹(*)이 있는지 확인
  function isMaskedAddr(info) {
    return info.addr && info.addr.indexOf('*') >= 0;
  }

  // ★ 상세보기/조회 링크+버튼 찾아서 클릭 시도
  function tryClickDetail() {
    let found = false;
    // 1차: <a> 태그 — ★ target="_blank" 제거하여 같은 탭에서 열기 (새 창으로 안 넘어가게)
    document.querySelectorAll('a').forEach(a => {
      if (found) return;
      const txt = a.textContent || '';
      const href = a.href || '';
      if (txt.includes('상세보기') || txt.includes('상세') || href.includes('E_billing') || href.includes('detail')) {
        // ★ 같은 탭에서 열리도록 target 제거
        if (a.target === '_blank' || a.target === '_new') a.target = '_self';
        a.click(); found = true;
        console.log('[BSN-KEPCO] Clicked detail link (same tab):', txt.trim().substring(0, 30));
      }
    });
    // 2차: <button>, <input type="button/submit/image"> 태그
    if (!found) {
      document.querySelectorAll('button, input[type="button"], input[type="submit"], input[type="image"]').forEach(el => {
        if (found) return;
        const txt = (el.textContent || el.value || el.alt || '').trim();
        if (txt.includes('상세보기') || txt.includes('상세') || txt.includes('전기요금 상세')) {
          el.click(); found = true;
          console.log('[BSN-KEPCO] Clicked detail button:', txt.substring(0, 30));
        }
      });
    }
    // 3차: <img> inside <a>
    if (!found) {
      document.querySelectorAll('img').forEach(img => {
        if (found) return;
        const parent = img.closest('a');
        if (parent && ((img.alt||'').includes('상세') || (img.src||'').includes('detail'))) {
          parent.click(); found = true;
        }
      });
    }
    // 4차: onclick 속성에 상세/detail 포함하는 요소
    if (!found) {
      document.querySelectorAll('[onclick]').forEach(el => {
        if (found) return;
        const oc = el.getAttribute('onclick') || '';
        if (oc.includes('detail') || oc.includes('E_billing') || oc.includes('상세')) {
          el.click(); found = true;
          console.log('[BSN-KEPCO] Clicked onclick element:', oc.substring(0, 50));
        }
      });
    }
    return found;
  }

  function runFlow(isAddrMode) {

    // ── 상세 청구서 페이지 (E_billing_NEW5 등) ──
    if (url.includes('E_billing_NEW5.jsp') || (url.includes('E_billing_NEW') && !url.includes('NEW4'))) {
      console.log('[BSN-KEPCO] Bill detail page!', isAddrMode ? '(addr → extract)' : '(capture)');

      if (isAddrMode) {
        // 주소가 렌더링될 때까지 최대 8초 대기 (1초 간격 재시도)
        let addrRetry = 0;
        const addrMaxRetry = 8;
        function tryExtractAddr() {
          addrRetry++;
          const info = extractAddrInfo();
          console.log('[BSN-KEPCO] Addr extract attempt', addrRetry, ':', JSON.stringify(info));
          if (info.addr && !isMaskedAddr(info)) {
            console.log('[BSN-KEPCO] ★ Full addr from detail (attempt ' + addrRetry + '):', JSON.stringify(info));
            chrome.runtime.sendMessage({ type: 'KEPCO_ADDR_EXTRACT', info: info });
          } else if (addrRetry < addrMaxRetry) {
            setTimeout(tryExtractAddr, 1000);
          } else {
            // 최대 재시도 초과 → 있는 것만 전송
            console.log('[BSN-KEPCO] Max retry reached, sending what we have:', JSON.stringify(info));
            chrome.runtime.sendMessage({ type: 'KEPCO_ADDR_EXTRACT', info: info });
          }
        }
        setTimeout(tryExtractAddr, 2500);
        return;
      }

      // 일반 캡처 모드
      setTimeout(() => {
        const bodyText = document.body.innerText || '';
        const info = {};
        // ★ 1순위: URL custid 파라미터 (가장 확실)
        try {
          const urlCustid = new URLSearchParams(location.search).get('custid') || '';
          if (urlCustid && /^\d{8,13}$/.test(urlCustid)) info.custNo = urlCustid;
        } catch(e) {}
        // 2순위: "고객번호" 라벨 매칭
        if (!info.custNo) {
          const cm = bodyText.match(/고\s*객\s*번\s*호\s*[:：]?\s*([\d\-]+)/);
          if (cm) info.custNo = cm[1].replace(/-/g, '');
        }
        // 3순위: "전자납부번호" 라벨 매칭
        if (!info.custNo) {
          const cm2 = bodyText.match(/전자\s*납부\s*번호\s*[:：)]\s*([\d\-]+)/);
          if (cm2) info.custNo = cm2[1].replace(/-/g, '');
        }
        // 4순위: XX-XXXX-XXXX 형식 (NEW5 상세 청구서)
        if (!info.custNo) {
          const cm3 = bodyText.match(/(\d{2})-(\d{4})-(\d{4})/);
          if (cm3) info.custNo = '0' + cm3[1] + cm3[2] + cm3[3];
        }
        // 5순위(최후): hidden input — 단, custid 파라미터가 있으면 그걸로 검증
        if (!info.custNo) {
          document.querySelectorAll('input[type="hidden"]').forEach(inp => {
            if (!info.custNo && /^\d{10,13}$/.test(inp.value || '')) info.custNo = inp.value;
          });
        }
        const pm = bodyText.match(/(\d{4})\s*년\s*(\d{1,2})\s*월/);
        if (pm) info.period = pm[1] + '-' + String(parseInt(pm[2])).padStart(2, '0');
        const am = bodyText.match(/청구금액[^0-9]{0,10}([\d,]+)/);
        if (am) info.amount = am[1].replace(/,/g, '');
        console.log('[BSN-KEPCO] Capture info:', JSON.stringify(info));
        let billRect = null;
        const candidates = document.querySelectorAll('table, div');
        let bestEl = null, bestScore = 0;
        candidates.forEach(el => {
          const txt = el.innerText || '';
          const rect = el.getBoundingClientRect();
          if (rect.width < 400 || rect.height < 300) return;
          let score = 0;
          if (txt.includes('고객번호')) score += 3;
          if (txt.includes('청구금액')) score += 3;
          if (txt.includes('사용량')) score += 2;
          if (txt.includes('전기요금')) score += 2;
          if (txt.includes('납기일')) score += 2;
          if (rect.height > window.innerHeight * 3) score -= 2;
          if (rect.height > 500 && rect.height < window.innerHeight * 2.5) score += 2;
          if (score > bestScore) { bestScore = score; bestEl = el; }
        });
        if (bestEl && bestScore >= 4) billRect = bestEl.getBoundingClientRect();
        window.scrollTo(0, 0);
        info._screenW = screen.availWidth || 1920;
        info._screenH = screen.availHeight || 1080;
        chrome.runtime.sendMessage({
          type: 'KEPCO_CAPTURE_AND_SEND', info: info,
          docHeight: Math.max(document.body.scrollHeight, document.documentElement.scrollHeight),
          viewHeight: window.innerHeight,
          billTop: billRect ? Math.floor(billRect.top + window.scrollY) : 0,
          billHeight: billRect ? Math.ceil(billRect.height) : 0,
          billWidth: billRect ? Math.ceil(billRect.width) : 0
        });
      }, 2500);
      return;
    }

    // ── 인증 페이지 (E_billing_NEW4) ──
    if (url.includes('E_billing_NEW4.jsp')) {
      console.log('[BSN-KEPCO] Verification page', isAddrMode ? '(addr mode)' : '');
      let authRetry = 0;
      const authMaxRetry = 5;
      function tryAuth() {
        authRetry++;
        const bodyText = document.body.innerText || '';
        const match = bodyText.match(/인증\s*번호\s*[:：]\s*(\d{4,6})/);
        if (!match) {
          if (authRetry < authMaxRetry) {
            console.log('[BSN-KEPCO] Auth code not found yet, retry', authRetry);
            setTimeout(tryAuth, 800);
            return;
          }
          // 최대 재시도 후에도 인증번호 없음
          if (isAddrMode) {
            const info = extractAddrInfo();
            if (info.addr && !isMaskedAddr(info)) {
              chrome.runtime.sendMessage({ type: 'KEPCO_ADDR_EXTRACT', info: info });
            }
          }
          return;
        }
        let inputField = null;
        document.querySelectorAll('input').forEach(inp => {
          if (inputField) return;
          if (['hidden','submit','button'].includes(inp.type)) return;
          if (inp.offsetParent !== null) inputField = inp;
        });
        if (!inputField) return;
        inputField.value = match[1];
        inputField.dispatchEvent(new Event('input', { bubbles: true }));
        inputField.dispatchEvent(new Event('change', { bubbles: true }));
        setTimeout(() => {
          // ★ 모든 form의 target을 _self로 변경 (새 창 방지)
          document.querySelectorAll('form').forEach(f => { if(f.target === '_blank' || f.target === '_new') f.target = '_self'; });
          let clicked = false;
          document.querySelectorAll('input[type="submit"],input[type="button"],input[type="image"],button,a').forEach(el => {
            if (clicked) return;
            if (el.target === '_blank' || el.target === '_new') el.target = '_self';
            const txt = (el.textContent || el.value || el.alt || '').trim();
            if (txt.includes('확인') || txt.includes('인증')) { el.click(); clicked = true; }
          });
          if (!clicked) { const f = document.querySelector('form'); if (f) { f.target = '_self'; f.submit(); } }
        }, 300);
      }
      setTimeout(tryAuth, 800);
      return;
    }

    // ── 요약/리다이렉트 페이지 ──
    if (url.includes('/indivisual_') || url.includes('/indivisual.') || url.includes('move_url.jsp')) {
      console.log('[BSN-KEPCO] Summary/redirect page', isAddrMode ? '(addr mode)' : '');
      setTimeout(() => {
        const clicked = tryClickDetail();
        if (isAddrMode) {
          if (clicked) {
            // 상세보기 클릭 성공 → 이 요약 탭은 바로 닫기 (상세는 새 탭에서 열림)
            console.log('[BSN-KEPCO] Detail clicked, closing summary tab');
            setTimeout(() => {
              chrome.runtime.sendMessage({ type: 'KEPCO_CLOSE_THIS_TAB' });
            }, 800);
          } else {
            // 상세보기 클릭 실패 → 현재 페이지에서 주소 추출 (마스킹이라도)
            const info = extractAddrInfo();
            console.log('[BSN-KEPCO] Detail click failed, sending current addr:', JSON.stringify(info));
            chrome.runtime.sendMessage({ type: 'KEPCO_ADDR_EXTRACT', info: info });
          }
        }
      }, 500);
      return;
    }

    // ── POST_PAGE (새 형식) ──
    if (url.includes('POST_PAGE.jsp') || url.includes('individual_POST')) {
      if (isAddrMode) {
        console.log('[BSN-KEPCO] POST_PAGE addr mode - looking for detail link...');
        setTimeout(() => {
          if (!tryClickDetail()) {
            const info = extractAddrInfo();
            if (info.addr && !isMaskedAddr(info)) {
              chrome.runtime.sendMessage({ type: 'KEPCO_ADDR_EXTRACT', info: info });
            } else {
              console.log('[BSN-KEPCO] Masked or no addr, waiting for redirect...');
            }
          }
        }, 700);
      } else {
        console.log('[BSN-KEPCO] POST_PAGE normal mode');
        setTimeout(() => {
          const info = extractAddrInfo();
          chrome.runtime.sendMessage({ type: 'KEPCO_ADDR_EXTRACT', info: info });
        }, 1000);
      }
      return;
    }

    // ── 기타 페이지 (리다이렉트 등) ──
    if (isAddrMode) {
      console.log('[BSN-KEPCO] Unknown page in addr mode:', url.substring(0, 80));
      setTimeout(() => {
        const info = extractAddrInfo();
        if (info.addr && !isMaskedAddr(info)) {
          console.log('[BSN-KEPCO] ★ Clean addr found:', JSON.stringify(info));
          chrome.runtime.sendMessage({ type: 'KEPCO_ADDR_EXTRACT', info: info });
        } else {
          console.log('[BSN-KEPCO] Masked/no addr, trying detail link...');
          if (!tryClickDetail()) {
            console.log('[BSN-KEPCO] No detail link, sending what we have');
            if (info.addr || info.custNo) {
              chrome.runtime.sendMessage({ type: 'KEPCO_ADDR_EXTRACT', info: info });
            }
          }
        }
      }, 800);
    }
  }
})();
