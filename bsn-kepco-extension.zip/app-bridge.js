// BSN.CARE ↔ Extension Bridge
// 역할: storage.local 폴링으로 캡처된 이미지를 앱에 전달 (postMessage + localStorage 이중)
(function() {
  'use strict';
  console.log('[BSN-Bridge] Script loaded, title=' + document.title);
  if (!document.title.includes('BSN')) return;
  console.log('[BSN-Bridge] Initialized');

  // 확장프로그램에 등록
  chrome.runtime.sendMessage({ type: 'BSN_REGISTER_APP' }, (r) => {
    if (chrome.runtime.lastError) {
      console.warn('[BSN-Bridge] Register error:', chrome.runtime.lastError.message);
      return;
    }
    console.log('[BSN-Bridge] Registered:', r);
  });

  // storage.local 폴링 (1초 간격)
  setInterval(function() {
    try {
      chrome.storage.local.get(['bsnCapturedImages', 'bsnDebug'], function(result) {
        if (chrome.runtime.lastError) return;

        // 디버그 정보 → localStorage에 복사 (main world에서 읽을 수 있도록)
        if (result.bsnDebug) {
          try {
            localStorage.setItem('bsn_debug', JSON.stringify(result.bsnDebug));
          } catch(e) {}
        }

        var data = result.bsnCapturedImages;
        if (!data || !data.images || !data.images.length) return;

        console.log('[BSN-Bridge] Found captured images:', data.images.length, 'for', data.custNo, data.period);

        // 1차: postMessage (기존 방식)
        window.postMessage({
          type: 'kepco-capture',
          custNo: data.custNo || '',
          period: data.period || '',
          images: data.images
        }, '*');

        // 2차: localStorage (백업 — main world 폴링용)
        try {
          localStorage.setItem('bsn_kepco_captured', JSON.stringify({
            custNo: data.custNo || '',
            period: data.period || '',
            images: data.images
          }));
          console.log('[BSN-Bridge] Also saved to localStorage');
        } catch(e) {
          console.warn('[BSN-Bridge] localStorage save failed:', e.message);
        }

        // storage 정리
        chrome.storage.local.remove(['bsnCapturedImages'], function() {
          if (chrome.runtime.lastError) return;
          console.log('[BSN-Bridge] Storage cleared');
        });
      });
    } catch(e) {
      console.warn('[BSN-Bridge] poll error:', e.message);
    }
  }, 1000);

  // 확장프로그램 연결 확인
  window.dispatchEvent(new CustomEvent('bsn-extension-ready'));
})();
