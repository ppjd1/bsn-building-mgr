// BSN - 앱 탭에 동적 주입되는 스크립트
// storage.local에서 캡처된 이미지를 꺼내서 window.postMessage로 앱에 전달
(function() {
  chrome.storage.local.get(['bsnCapturedImages'], function(result) {
    var data = result.bsnCapturedImages;
    if (!data || !data.images || !data.images.length) {
      console.warn('[BSN-Fetch] No images in storage');
      return;
    }
    console.log('[BSN-Fetch] Found', data.images.length, 'images for', data.custNo, data.period);

    // 이미지를 1장씩 postMessage
    data.images.forEach(function(img) {
      window.postMessage({
        type: 'kepco-capture',
        custNo: data.custNo || '',
        period: data.period || '',
        images: [img]
      }, '*');
    });

    // storage 정리
    chrome.storage.local.remove(['bsnCapturedImages']);
    console.log('[BSN-Fetch] Done, storage cleared');
  });
})();
