// BSN.CARE 아리수 자동조회 확장프로그램 v2.1
// ① hash 진입 → 자동입력+조회+sessionStorage
// ② 결과 페이지 → 파싱 → background에 캡처 요청 → BSN케어 전송
(function() {
  'use strict';
  var SS_KEY = 'bsn_water_auto';
  var RESULT_WAIT_MAX = 12000;
  var RESULT_CHECK_INTERVAL = 600;

  function log(msg) { console.log('[BSN-ext] ' + msg); }

  // ─── 1단계: #bsn= hash → 자동입력 + 조회 ───
  var hash = window.location.hash;
  if (hash && hash.indexOf('#bsn=') === 0) {
    log('1단계: hash 감지');
    var raw = decodeURIComponent(hash.substring(5));
    var parts = raw.split('|');
    var custNo = parts[0] || '';
    var custName = parts[1] || '';
    var wid = parts[2] || '';
    if (!custNo) return;

    history.replaceState(null, '', window.location.pathname + window.location.search);

    try {
      sessionStorage.setItem(SS_KEY, JSON.stringify({
        custNo: custNo, custName: custName, wid: wid, ts: Date.now()
      }));
    } catch(e) {}

    function tryFill() {
      var mk = document.getElementById('mkey');
      if (!mk) { setTimeout(tryFill, 500); return; }
      mk.focus(); mk.value = custNo;
      mk.dispatchEvent(new Event('input', {bubbles:true}));
      mk.dispatchEvent(new Event('change', {bubbles:true}));

      if (custName) {
        var cs = document.getElementById('csNm');
        if (cs) {
          cs.focus(); cs.value = custName;
          cs.dispatchEvent(new Event('input', {bubbles:true}));
          cs.dispatchEvent(new Event('change', {bubbles:true}));
        }
      }

      var btns = document.querySelectorAll('button, a, input[type="button"], input[type="submit"]');
      var best = null, bestScore = 0;
      for (var i = 0; i < btns.length; i++) {
        var b = btns[i];
        var t = (b.textContent || b.value || '').trim();
        var oc = (b.getAttribute('onclick') || '');
        if (/전체|목록|이전|다음|취소|초기화|인쇄|닫기/.test(t)) continue;
        if (/cgTotal|Total\.do|List\.do|goTotal|history/.test(oc)) continue;
        var score = 0;
        if (t === '조회') score += 100;
        else if (t === '검색') score += 80;
        if (b.type === 'submit') score += 40;
        if (/fnSearch/.test(oc)) score += 30;
        if (/btn.?search/i.test(b.className)) score += 15;
        if (score > bestScore) { bestScore = score; best = b; }
      }
      if (best && bestScore >= 30) {
        log('조회 버튼 클릭 (score=' + bestScore + ')');
        setTimeout(function() { best.click(); }, 400);
      }
    }
    setTimeout(tryFill, 1000);
    return;
  }

  // ─── 2단계: 결과 페이지 → 파싱 + 캡처 + 전송 ───
  var stored = null;
  try {
    var raw2 = sessionStorage.getItem(SS_KEY);
    if (raw2) stored = JSON.parse(raw2);
  } catch(e) {}
  if (!stored || !stored.custNo || (Date.now() - stored.ts > 600000)) return;

  log('2단계: 결과 감지 시작 (' + stored.custNo + ')');

  var waited = 0;
  function checkResult() {
    var body = document.body ? document.body.innerText : '';
    if (/납부금액|총\s*사용금액|상수도요금|하수도요금/.test(body)) {
      log('결과 감지됨');
      sessionStorage.removeItem(SS_KEY);
      setTimeout(parseAndCapture, 500); // 렌더링 완료 대기
      return;
    }
    waited += RESULT_CHECK_INTERVAL;
    if (waited < RESULT_WAIT_MAX) {
      setTimeout(checkResult, RESULT_CHECK_INTERVAL);
    } else {
      log('결과 대기 타임아웃');
    }
  }
  setTimeout(checkResult, 800);

  function parseAndCapture() {
    var body = document.body ? document.body.innerText : '';

    // 기간
    var period = '';
    var pm = body.match(/(\d{4})\s*년\s*(\d{1,2})\s*월\s*상/);
    if (!pm) pm = body.match(/(\d{4})\s*년\s*(\d{1,2})\s*월\s*납기/);
    if (!pm) pm = body.match(/(\d{4})\s*년\s*(\d{1,2})\s*월/);
    if (pm) {
      period = pm[1] + '-' + (pm[2].length === 1 ? '0' + pm[2] : pm[2]);
    } else {
      var now = new Date();
      period = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
    }

    // 금액
    var amount = '';
    var am = body.match(/납부금액\s*[:\s]*([0-9,]+)\s*원?/);
    if (am) amount = am[1].replace(/,/g, '');

    // 사용량
    var usage = '';
    var um = body.match(/사용량\s*[:\s]*([0-9,.]+)\s*[㎥m³]?/);
    if (um) usage = um[1];

    // 정기검침일 — 다양한 패턴 매칭
    var meterDay = '';
    var md = body.match(/정기검침일\s*[(\s]*(\d{1,2})/);
    if (!md) md = body.match(/검침일\s*[:\s]*(?:매월\s*)?(\d{1,2})\s*일/);
    if (!md) md = body.match(/검침[:\s]*(?:홀수월|짝수월)?\s*(\d{1,2})\s*일/);
    if (!md) md = body.match(/계량기\s*검침[에일:\s]*(?:\d{1,2}월\s*[,\s]*)?(\d{1,2})\s*일/);
    if (!md) md = body.match(/(\d{1,2})\s*일\s*지침/);
    if (md) meterDay = md[1];

    // 홀짝수월
    var meterCycle = '';
    var cycleMatch = body.match(/(\d{1,2})월\s*지침[\s\S]*?(\d{1,2})월\s*지침/);
    if (cycleMatch) {
      var m1 = parseInt(cycleMatch[1]); var m2 = parseInt(cycleMatch[2]);
      if (m1 % 2 === 1 && m2 % 2 === 1) meterCycle = 'odd';
      else if (m1 % 2 === 0 && m2 % 2 === 0) meterCycle = 'even';
    }
    if (!meterCycle) {
      var periodMatch = body.match(/사용기간\s*(\d{4})년\s*(\d{1,2})월/);
      if (periodMatch) {
        var startMonth = parseInt(periodMatch[2]);
        meterCycle = (startMonth % 2 === 1) ? 'odd' : 'even';
      }
    }

    log('파싱: period=' + period + ' amount=' + amount + ' meterDay=' + meterDay + ' meterCycle=' + meterCycle);

    // ★ 청구서 영역 찾기 — 아리수 페이지의 파란 박스 / 테이블 영역
    var billArea = document.querySelector('.box_type1') || document.querySelector('.bill_box')
      || document.querySelector('.tbl_view') || document.querySelector('#printArea')
      || document.querySelector('.content_wrap') || document.querySelector('#content')
      || document.querySelector('.sub_content');
    // 못 찾으면 가장 큰 테이블로 폴백
    if (!billArea) {
      var allTables = document.querySelectorAll('table');
      var biggest = null, biggestArea = 0;
      for (var ti = 0; ti < allTables.length; ti++) {
        var r = allTables[ti].getBoundingClientRect();
        var area = r.width * r.height;
        if (area > biggestArea) { biggestArea = area; biggest = allTables[ti]; }
      }
      if (biggest) billArea = biggest;
    }

    // 청구서 영역을 화면 상단으로 스크롤
    if (billArea) {
      try { billArea.scrollIntoView({ block: 'start', behavior: 'instant' }); } catch(e) {}
    }
    try { window.focus(); } catch(e) {}

    // chrome.runtime 존재 여부 확인
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      log('⚠ chrome.runtime 없음');
      _captureFallback(period, amount, usage, meterDay, meterCycle);
      return;
    }

    // ★ captureVisibleTab 스크린샷 → 청구서 영역만 크롭
    // 캡처 전 기존 배너 제거 (스크린샷에 찍히지 않도록)
    var oldBanner = document.getElementById('bsn-ext-banner');
    if (oldBanner) oldBanner.remove();

    setTimeout(function() {
      chrome.runtime.sendMessage({ type: 'bsn_capture_tab' }, function(resp) {
        if (chrome.runtime.lastError) {
          log('❌ sendMessage 에러: ' + chrome.runtime.lastError.message);
          _captureFallback(period, amount, usage, meterDay, meterCycle);
          return;
        }
        if (!resp || !resp.ok || !resp.dataUrl) {
          log('❌ captureVisibleTab 실패');
          _captureFallback(period, amount, usage, meterDay, meterCycle);
          return;
        }
        log('✅ captureVisibleTab 성공: ' + (resp.dataUrl.length / 1024).toFixed(0) + 'KB');

        // 청구서 영역 크롭
        if (billArea) {
          _cropToElement(resp.dataUrl, billArea, function(croppedUrl) {
            if (croppedUrl) {
              log('✅ 크롭 완료: ' + (croppedUrl.length / 1024).toFixed(0) + 'KB');
              sendToBSN(croppedUrl, period, amount, usage, meterDay, meterCycle);
            } else {
              log('크롭 실패 → 전체 스크린샷 사용');
              sendToBSN(resp.dataUrl, period, amount, usage, meterDay, meterCycle);
            }
          });
        } else {
          sendToBSN(resp.dataUrl, period, amount, usage, meterDay, meterCycle);
        }
      });
    }, 500); // 스크롤 완료 대기

    // ★ 스크린샷에서 특정 엘리먼트 영역만 크롭
    function _cropToElement(fullDataUrl, el, cb) {
      try {
        var rect = el.getBoundingClientRect();
        var dpr = window.devicePixelRatio || 1;
        // 여백 약간 추가 (위아래 10px, 좌우 5px)
        var cx = Math.max(0, Math.floor((rect.left - 5) * dpr));
        var cy = Math.max(0, Math.floor((rect.top - 10) * dpr));
        var cw = Math.ceil((rect.width + 10) * dpr);
        var ch = Math.ceil((rect.height + 20) * dpr);

        var img = new Image();
        img.onload = function() {
          // 이미지 범위 초과 방지
          if (cx + cw > img.width) cw = img.width - cx;
          if (cy + ch > img.height) ch = img.height - cy;
          if (cw < 50 || ch < 50) { cb(null); return; }

          var canvas = document.createElement('canvas');
          canvas.width = cw;
          canvas.height = ch;
          var ctx = canvas.getContext('2d');
          ctx.drawImage(img, cx, cy, cw, ch, 0, 0, cw, ch);
          var cropped = canvas.toDataURL('image/png');
          cb(cropped);
        };
        img.onerror = function() { cb(null); };
        img.src = fullDataUrl;
      } catch(e) {
        log('크롭 에러: ' + e.message);
        cb(null);
      }
    }

    // ★ 최종 폴백: 텍스트 이미지 생성 (captureVisibleTab도 실패 시)
    function _captureFallback(per, amt, usg, md, mc) {
      log('📝 최종 폴백: 텍스트 이미지 생성');
      showBanner('📝 텍스트 이미지 생성 중...', '#d97706');
      try {
        var canvas = document.createElement('canvas');
        canvas.width = 700; canvas.height = 420;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, 700, 420);
        ctx.fillStyle = '#1e3a8a'; ctx.fillRect(0, 0, 700, 52);
        ctx.fillStyle = '#fff'; ctx.font = 'bold 16px sans-serif';
        ctx.fillText('서울특별시 수도요금 청구서', 18, 33);
        ctx.font = '11px sans-serif'; ctx.fillStyle = '#93c5fd';
        ctx.fillText((stored.custName || '') + ' · ' + (stored.custNo || ''), 18, 48);
        ctx.fillStyle = '#1e293b'; ctx.font = 'bold 15px sans-serif';
        var y = 90;
        ctx.fillText('청구기간: ' + (per || '-'), 30, y); y += 34;
        if (amt) { ctx.fillText('납부금액: ' + Number(amt).toLocaleString() + '원', 30, y); y += 34; }
        if (usg) { ctx.fillText('사용량: ' + usg + '㎥', 30, y); y += 34; }
        if (md) { ctx.fillText('정기검침일: 매 ' + md + '일', 30, y); y += 34; }
        if (mc) { ctx.fillText('청구주기: ' + (mc === 'odd' ? '홀수월' : mc === 'even' ? '짝수월' : mc), 30, y); y += 34; }
        ctx.fillStyle = '#94a3b8'; ctx.font = '9px sans-serif';
        ctx.fillText('BSN.CARE · ' + new Date().toLocaleString('ko'), 30, 410);
        var dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        sendToBSN(dataUrl, per, amt, usg, md, mc);
      } catch(e) {
        sendToBSN(null, per, amt, usg, md, mc);
      }
    }
  }

  function sendToBSN(dataUrl, period, amount, usage, meterDay, meterCycle) {
    var payload = {
      type: 'bsn_water_bill',
      wid: stored.wid || '',
      custNo: stored.custNo || '',
      custName: stored.custName || '',
      period: period,
      amount: amount,
      usage: usage,
      meterDay: meterDay || '',
      meterCycle: meterCycle || '',
      ts: Date.now()
    };
    if (dataUrl) payload.dataUrl = dataUrl;

    // 1) opener (iframe 안에서 실행될 수 있으므로 window.top.opener도 시도)
    var openerRef = null;
    try { if(window.top && window.top.opener && !window.top.opener.closed) openerRef = window.top.opener; } catch(e) { log('top.opener 접근 실패(cross-origin): ' + e.message); }
    if(!openerRef) { try { if(window.opener && !window.opener.closed) openerRef = window.opener; } catch(e) {} }
    if(!openerRef) { try { if(window.parent && window.parent.opener && !window.parent.opener.closed) openerRef = window.parent.opener; } catch(e) {} }
    if (openerRef) {
      try {
        openerRef.postMessage(payload, '*');
        log('✅ opener 전송 성공');
        showBanner('✅ 청구서 저장 완료! BSN케어에서 확인하세요.', '#059669');
        setTimeout(function() { try { window.close(); } catch(_){} }, 2000);
        return;
      } catch(e) { log('opener 실패: ' + e.message); }
    }

    // 2) BroadcastChannel
    try {
      var bc = new BroadcastChannel('bsn_water');
      bc.postMessage(payload);
      bc.close();
      log('✅ BroadcastChannel 전송 성공');
      showBanner('✅ 청구서 저장 완료! BSN케어에서 확인하세요.', '#059669');
      setTimeout(function() { try { window.close(); } catch(_){} }, 2000);
      return;
    } catch(e) { log('BroadcastChannel 실패: ' + e.message); }

    // 3) 다운로드 폴백
    if (dataUrl) {
      var a = document.createElement('a');
      a.href = dataUrl;
      a.download = 'water_' + (stored.custNo || '') + '_' + period + '.jpg';
      a.click();
      showBanner('⚠ BSN케어 연결 실패 — 파일로 저장됨', '#d97706');
    } else {
      showBanner('⚠ 캡처+전송 실패', '#dc2626');
    }
  }

  function showBanner(msg, color) {
    var old = document.getElementById('bsn-ext-banner');
    if (old) old.remove();
    var d = document.createElement('div');
    d.id = 'bsn-ext-banner';
    d.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;padding:14px 20px;font-size:14px;font-weight:700;text-align:center;color:#fff;font-family:-apple-system,sans-serif;background:' + (color || '#059669') + ';box-shadow:0 2px 12px rgba(0,0,0,.2)';
    d.textContent = msg;
    document.body.appendChild(d);
    setTimeout(function() { try { d.remove(); } catch(_){} }, 5000);
  }
})();
