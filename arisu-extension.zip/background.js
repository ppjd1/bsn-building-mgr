// BSN.CARE 아리수 자동조회 — background service worker
// content.js에서 캡처 요청 → captureVisibleTab → dataUrl 회신

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'bsn_capture_tab') {
    var windowId = sender.tab.windowId;
    var tabId = sender.tab.id;
    console.log('[BSN-bg] 캡처 요청 수신: windowId=' + windowId + ', tabId=' + tabId);

    // ★ 탭을 활성화(포커스)한 뒤 캡처 — 비활성 탭이면 captureVisibleTab 실패함
    chrome.tabs.update(tabId, { active: true }, function() {
      // 탭 활성화 후 약간 대기 (렌더링 완료)
      setTimeout(function() {
        _doCapture(windowId, 0, sendResponse);
      }, 300);
    });
    return true; // 비동기 응답
  }
});

// 캡처 시도 (최대 3회 재시도)
function _doCapture(windowId, attempt, sendResponse) {
  chrome.tabs.captureVisibleTab(windowId, {
    format: 'png'
  }, function(dataUrl) {
    if (chrome.runtime.lastError) {
      var errMsg = chrome.runtime.lastError.message;
      console.warn('[BSN-bg] 캡처 실패 (시도 ' + (attempt+1) + '/3):', errMsg);
      if (attempt < 2) {
        // 재시도 (500ms 대기)
        setTimeout(function() { _doCapture(windowId, attempt + 1, sendResponse); }, 500);
      } else {
        console.error('[BSN-bg] 캡처 최종 실패:', errMsg);
        sendResponse({ ok: false, error: errMsg });
      }
    } else {
      console.log('[BSN-bg] 캡처 성공 (시도 ' + (attempt+1) + '):', (dataUrl.length / 1024).toFixed(0) + 'KB');
      sendResponse({ ok: true, dataUrl: dataUrl });
    }
  });
}
